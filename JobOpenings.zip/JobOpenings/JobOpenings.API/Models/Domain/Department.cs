﻿namespace JobOpenings.API.Models.Domain
{
    public class Department
    {
        public int DepartmentId { get; set; }
        public string DepartmentTitle { get; set; }
    }
}
