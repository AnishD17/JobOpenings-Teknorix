﻿namespace JobOpenings.API.Models.DTO
{
    public class DepartmentResponse
    {
        public int DepartmentId { get; set; }
        public string DepartmentTitle { get; set; }
    }
}
