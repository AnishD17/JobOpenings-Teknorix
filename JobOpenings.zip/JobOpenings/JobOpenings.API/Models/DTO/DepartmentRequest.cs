﻿namespace JobOpenings.API.Models.DTO
{
    public class DepartmentRequest
    {
        public string? DepartmentTitle { get; set; }
    }
}
